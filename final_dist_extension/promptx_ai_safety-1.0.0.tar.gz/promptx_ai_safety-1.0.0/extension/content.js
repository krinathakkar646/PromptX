(function () {
  "use strict";

  const API_URL = "http://127.0.0.1:5000/api/analyze";
  const HIGH_RISK_SCORE = 50;
  let lastPrompt = "";
  let lastResult = null;
  let scanInProgress = false;

  function getInput() {
    const active = document.activeElement;
    if (active && (active.tagName === "TEXTAREA" || active.isContentEditable)) {
      return active;
    }
    return document.querySelector("textarea") ||
      document.querySelector("[contenteditable='true']");
  }

  function readPrompt(input) {
    return input.tagName === "TEXTAREA" ? input.value.trim() : input.innerText.trim();
  }

  function createPanel() {
    let panel = document.getElementById("promptx-safety-panel");
    if (panel) return panel;
    panel = document.createElement("div");
    panel.id = "promptx-safety-panel";
    panel.innerHTML = `
      <div class="promptx-header">
        <strong>PromptX Safety Check</strong>
        <button type="button" aria-label="Close">×</button>
      </div>
      <div class="promptx-body">Enter a prompt to scan it.</div>
    `;
    document.body.appendChild(panel);
    panel.querySelector("button").addEventListener("click", () => panel.remove());
    return panel;
  }

  function showResult(result) {
    const panel = createPanel();
    const score = result.risk_scoring_engine.calculated_score;
    const classification = result.risk_classification;
    const findings = Object.values(result.security_analysis_modules || {})
      .filter((item) => item && item.risk_detected)
      .map((item) => item.threat_type || item.module_name || "Security finding");
    const colour = score >= HIGH_RISK_SCORE ? "#b42318" : score > 0 ? "#b54708" : "#027a48";
    panel.querySelector(".promptx-body").innerHTML = `
      <div class="promptx-score" style="color:${colour}">${classification} · ${score}/100</div>
      <div>${findings.length ? findings.join(", ") : "No security issues detected."}</div>
      ${score >= HIGH_RISK_SCORE ? `
        <div class="promptx-warning">This prompt has a high risk score. Review it before sending.</div>
        <button type="button" class="promptx-confirm">Send anyway</button>
      ` : ""}
    `;
    panel.querySelector(".promptx-confirm")?.addEventListener("click", () => {
      lastResult = { ...result, confirmed: true };
      panel.remove();
      const input = getInput();
      input?.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
    });
  }

  async function scan(input) {
    const prompt = readPrompt(input);
    if (!prompt || scanInProgress) return;
    scanInProgress = true;
    const panel = createPanel();
    panel.querySelector(".promptx-body").textContent = "Scanning with local PromptX API...";
    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt })
      });
      if (!response.ok) throw new Error(`API returned ${response.status}`);
      const result = await response.json();
      lastPrompt = prompt;
      lastResult = result;
      showResult(result);
    } catch (error) {
      panel.querySelector(".promptx-body").textContent =
        "PromptX API is unavailable. Start the Flask server before sending.";
    } finally {
      scanInProgress = false;
    }
  }

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" || event.shiftKey || event.isComposing) return;
    const input = getInput();
    if (!input || !readPrompt(input)) return;
    const prompt = readPrompt(input);
    if (lastPrompt === prompt && lastResult?.confirmed) {
      lastPrompt = "";
      lastResult = null;
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    scan(input);
  }, true);

  const style = document.createElement("style");
  style.textContent = `
    #promptx-safety-panel { position:fixed; right:20px; bottom:20px; z-index:2147483647;
      width:320px; color:#172033; background:#fff; border:1px solid #d0d5dd;
      border-radius:12px; box-shadow:0 8px 28px #0003; font:14px Arial,sans-serif; }
    .promptx-header { display:flex; justify-content:space-between; align-items:center;
      padding:12px 14px; background:#172033; color:#fff; border-radius:12px 12px 0 0; }
    .promptx-header button { border:0; background:transparent; color:#fff; font-size:20px; cursor:pointer; }
    .promptx-body { padding:14px; line-height:1.45; }
    .promptx-score { font-size:18px; font-weight:700; margin-bottom:8px; }
    .promptx-warning { margin-top:12px; padding:9px; background:#fff3cd; border-radius:6px; }
    .promptx-confirm { margin-top:12px; padding:8px 12px; border:0; border-radius:6px;
      color:#fff; background:#b42318; cursor:pointer; }
  `;
  document.documentElement.appendChild(style);
})();
